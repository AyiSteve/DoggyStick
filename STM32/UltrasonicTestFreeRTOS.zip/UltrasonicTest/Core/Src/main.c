/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "cmsis_os.h"
#include "i2c.h"
#include "i2s.h"
#include "tim.h"
#include "usart.h"
#include "usb_host.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "usb_host.h"
#include "stm32f4xx_hal.h"
#include "stdio.h"
#include "liquidcrystal_i2c.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
void MX_FREERTOS_Init(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
typedef enum {
    HCSR04_IDLE,
    HCSR04_TRIGGERED,
    HCSR04_WAITING_ECHO,
    HCSR04_DONE
} HCSR04_State;

typedef struct {
    uint32_t ic_start;
    uint32_t ic_end;
    uint32_t echo_time;
    uint8_t  captured;
    uint32_t last_trigger_time;
    HCSR04_State state;
} HCSR04_t;

HCSR04_t hcsr04[3];

static const GPIO_TypeDef* trig_port[3] = { GPIOA, GPIOA, GPIOB };
static const uint16_t      trig_pin[3]  = { GPIO_PIN_6, GPIO_PIN_7, GPIO_PIN_0 };
static const uint32_t      tim_channel[3] = { TIM_CHANNEL_1, TIM_CHANNEL_2, TIM_CHANNEL_3 };


void delay_us(uint32_t us)
{
    uint32_t cycles = (SystemCoreClock / 1000000) * us;
    uint32_t start = DWT->CYCCNT;

    while ((DWT->CYCCNT - start) < cycles);
}


void HCSR04_Start(uint8_t sensor)
{
    // 10us pulse
    HAL_GPIO_WritePin((GPIO_TypeDef*)trig_port[sensor], trig_pin[sensor], GPIO_PIN_RESET);
    delay_us(2);
    HAL_GPIO_WritePin((GPIO_TypeDef*)trig_port[sensor], trig_pin[sensor], GPIO_PIN_SET);
    delay_us(10);
    HAL_GPIO_WritePin((GPIO_TypeDef*)trig_port[sensor], trig_pin[sensor], GPIO_PIN_RESET);

    // Reset timer and start capture
    __HAL_TIM_SET_COUNTER(&htim2, 0);
    HAL_TIM_IC_Start_IT(&htim2, tim_channel[sensor]);

    hcsr04[sensor].captured = 0;
    hcsr04[sensor].state = HCSR04_TRIGGERED;
    hcsr04[sensor].last_trigger_time = HAL_GetTick();
}



void HAL_TIM_IC_CaptureCallback(TIM_HandleTypeDef *htim)
{
    if (htim->Instance != TIM2)
        return;

    uint8_t idx;

    if      (htim->Channel == HAL_TIM_ACTIVE_CHANNEL_1) idx = 0;
    else if (htim->Channel == HAL_TIM_ACTIVE_CHANNEL_2) idx = 1;
    else if (htim->Channel == HAL_TIM_ACTIVE_CHANNEL_3) idx = 2;
    else return;

    if (hcsr04[idx].captured == 0)
    {
        hcsr04[idx].ic_start = HAL_TIM_ReadCapturedValue(htim, tim_channel[idx]);
        hcsr04[idx].captured = 1;

        __HAL_TIM_SET_CAPTUREPOLARITY(htim, tim_channel[idx],
                                      TIM_INPUTCHANNELPOLARITY_FALLING);
    }
    else
    {
        hcsr04[idx].ic_end = HAL_TIM_ReadCapturedValue(htim, tim_channel[idx]);

        if (hcsr04[idx].ic_end >= hcsr04[idx].ic_start)
            hcsr04[idx].echo_time = hcsr04[idx].ic_end - hcsr04[idx].ic_start;
        else
            hcsr04[idx].echo_time = (0xFFFFFFFF - hcsr04[idx].ic_start) + hcsr04[idx].ic_end;

        hcsr04[idx].state = HCSR04_DONE;

        __HAL_TIM_SET_CAPTUREPOLARITY(htim, tim_channel[idx],
                                      TIM_INPUTCHANNELPOLARITY_RISING);

        HAL_TIM_IC_Stop_IT(htim, tim_channel[idx]);
    }
}

void HCSR04_Update(void)
{
    static uint8_t current = 0;

    switch (hcsr04[current].state)
    {
        case HCSR04_IDLE:
            HCSR04_Start(current);
            break;

        case HCSR04_TRIGGERED:
            // Waiting for echo to start
            if (HAL_GetTick() - hcsr04[current].last_trigger_time > 50)
            {
                // Timeout → no echo
                hcsr04[current].echo_time = 0;
                hcsr04[current].state = HCSR04_DONE;
            }
            break;

        case HCSR04_DONE:
            // Move to next sensor
            current = (current + 1) % 3;
            hcsr04[current].state = HCSR04_IDLE;
            break;
    }
}

float HCSR04_GetDistance(uint8_t sensor)
{
    return (hcsr04[sensor].echo_time * 0.0343f) / 2.0f;
}



/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_I2C1_Init();
  MX_I2S3_Init();
  MX_TIM2_Init();
  MX_USART3_UART_Init();
  /* USER CODE BEGIN 2 */

  HD44780_Init(2);
  HD44780_Clear();
  HD44780_Backlight();
//  HD44780_SetCursor(0,0);
//  HD44780_PrintStr("Welcome To");
//  HD44780_SetCursor(0,1);
//  HD44780_PrintStr("GOAT HQ");
  /* USER CODE END 2 */

  /* Init scheduler */
  osKernelInitialize();  /* Call init function for freertos objects (in cmsis_os2.c) */
  MX_FREERTOS_Init();

  /* Start scheduler */
  osKernelStart();

  /* We should never get here as control is now taken by the scheduler */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */

  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 8;
  RCC_OscInitStruct.PLL.PLLN = 336;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 7;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV4;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV2;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_5) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  Period elapsed callback in non blocking mode
  * @note   This function is called  when TIM6 interrupt took place, inside
  * HAL_TIM_IRQHandler(). It makes a direct call to HAL_IncTick() to increment
  * a global variable "uwTick" used as application time base.
  * @param  htim : TIM handle
  * @retval None
  */
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
  /* USER CODE BEGIN Callback 0 */

  /* USER CODE END Callback 0 */
  if (htim->Instance == TIM6)
  {
    HAL_IncTick();
  }
  /* USER CODE BEGIN Callback 1 */

  /* USER CODE END Callback 1 */
}

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}
#ifdef USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
